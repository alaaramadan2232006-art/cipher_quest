@echo off
setlocal EnableExtensions
chcp 65001 >nul
title Cipher Quest - Build Desktop Game
cd /d "%~dp0"

rem Keep temporary build files and package caches on this drive, not C:.
set "TEMP=%CD%\_build_temp"
set "TMP=%CD%\_build_temp"
set "PIP_CACHE_DIR=%CD%\_pip_cache"
set "PYINSTALLER_CONFIG_DIR=%CD%\_pyinstaller_config"
if not exist "%TEMP%" mkdir "%TEMP%"
if not exist "%PIP_CACHE_DIR%" mkdir "%PIP_CACHE_DIR%"
if not exist "%PYINSTALLER_CONFIG_DIR%" mkdir "%PYINSTALLER_CONFIG_DIR%"
if not exist "assets" mkdir "assets"

echo.
echo ==============================================
echo   CIPHER QUEST - MAKE A DOUBLE-CLICK GAME
 echo ==============================================
echo.
echo This is a one-time setup. Please keep this window open.
echo The game will be built on this drive to reduce use of C:.
echo.

if not exist ".venv\Scripts\python.exe" (
    echo Creating a local Python environment...
    py -m venv .venv
    if errorlevel 1 goto :fail
)

echo Installing the game builder and Pygame. Internet is needed for this step.
".venv\Scripts\python.exe" -m pip install --disable-pip-version-check --no-cache-dir pygame-ce pyinstaller
if errorlevel 1 goto :fail

echo.
echo Building the standalone game. This may take a few minutes...
".venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean --onedir --windowed --name "Cipher Quest" --collect-all pygame --add-data "assets;assets" --workpath "%CD%\_pyinstaller_build" --distpath "%CD%\dist" --specpath "%CD%\_pyinstaller_spec" "cipher_quest_pink_cyber.py"
if errorlevel 1 goto :fail

echo.
echo ==============================================
echo   BUILD COMPLETE!
echo ==============================================
echo.
echo Your game is here:
echo   %CD%\dist\Cipher Quest\Cipher Quest.exe
echo.
echo Starting the game now...
start "" "%CD%\dist\Cipher Quest\Cipher Quest.exe"
echo.
echo To play next time, open the EXE directly. No VS Code or commands needed.
echo You can right-click the EXE and choose Send to ^> Desktop (create shortcut).
echo.
pause
exit /b 0

:fail
echo.
echo The build did not finish. Take a photo of this window and send it here.
echo Do not delete the .venv, assets, or build files yet.
pause
exit /b 1
